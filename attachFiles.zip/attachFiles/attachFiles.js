import { LightningElement, api, track, wire } from 'lwc';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import REQUIREDATTACHMENTS_FIELD from '@salesforce/schema/ContentVersion.Required_Attachments__c';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import CONTENTVERSION_OBJECT from '@salesforce/schema/ContentVersion';

export default class AttachFiles extends LightningElement {
    @api recordId;
    @track files;
    filetype = ['.png', '.jpg', '.jpeg', '.pdf', '.csv', '.xlsx', '.pptx'];

    @wire(getObjectInfo, { objectApiName: CONTENTVERSION_OBJECT })
    objectInfo;

    @wire(getPicklistValues, { recordTypeId: '$objectInfo.data.defaultRecordTypeId', fieldApiName: REQUIREDATTACHMENTS_FIELD })
    attachmentPickListValues;

    handleUploadFinished(event) {
        const newFiles = event.detail.files;
        console.log('newFiles');
        console.log(newFiles);
        this.files = [];
        newFiles.forEach((newFile) => {
            this.files.push(newFile);
        });


        console.log(' this.files');
        console.log( this.files);
        this.dispatchEvent(new CustomEvent('fileschange', { detail: this.files }));

    }

    handleRemoveFile(event) {
        const fileId = event.target.name;
        this.files = this.files.filter(file => file.documentId !== fileId);

        if (this.files.length === 0) {
            this.files = undefined;
        }
    }
}